bash script.sh > output/201401074_output
