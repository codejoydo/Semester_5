g++ code/codefile.cpp
./a.out input/100MB_20Percent 1 1 3
./a.out input/100MB_20Percent 2 1 3
./a.out input/1MB_50Percent 1 1 3
./a.out input/1MB_50Percent 2 1 3

./a.out input/100MB_20Percent 1 2 5
./a.out input/100MB_20Percent 2 2 5
./a.out input/1MB_50Percent 1 2 5
./a.out input/1MB_50Percent 2 2 5

./a.out input/100MB_20Percent 1 0.1 10
./a.out input/100MB_20Percent 2 0.1 10
./a.out input/1MB_50Percent 1 0.1 10
./a.out input/1MB_50Percent 2 0.1 10
