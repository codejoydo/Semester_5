mkdir output
bash 1.sh > output/201401180_output
