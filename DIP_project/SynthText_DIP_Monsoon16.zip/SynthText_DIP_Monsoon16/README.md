# SynthText_DIP_Monsoon16
Synthetic Data for Text Localisation in Natural Images - Project for Digital Image Processing Course, Monsoon 16
