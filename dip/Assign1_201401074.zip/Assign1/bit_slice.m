A = rgb2gray(imread('lena1.jpg'));
B = rgb2gray(imread('lena2.jpg'));

A1=bitget(A,1); 
A2=bitget(A,2); 
A3=bitget(A,3);
A4=bitget(A,4);
A5=bitget(A,5); 
A6=bitget(A,6);
A7=bitget(A,7); 
A8=bitget(A,8); 
B1=bitget(B,1); 
B2=bitget(B,2); 
B3=bitget(B,3);
B4=bitget(B,4);
B5=bitget(B,5);
B6=bitget(B,6); 
B7=bitget(B,7); 
B8=bitget(B,8); 

imshow(A);
% B1 = B1*255;
% B1 = uint8(B1);
% imwrite(B1,'B1.png');
B1 = rgb2gray(imread('B1.png'));
B1 = B1/255;

out = zeros(512,512);
out = uint8(out);
out = out + A1;
out = out + A2*2;
out = out + A3*4;
out = out + A4*8;
out = out + A5*16;
out = out + A6*32;
out = out + A7*64;
out = out + A8*128;
imwrite(out,'22.png');


h = fspecial('average', 3);
filter2(h, A);

figure,imshow(logical(A1));
figure,imshow(logical(A2));
figure,imshow(logical(A3));
figure,imshow(logical(A4));
figure,imshow(logical(A5));
figure,imshow(logical(A6));
figure,imshow(logical(A7));
figure,imshow(logical(A8));
