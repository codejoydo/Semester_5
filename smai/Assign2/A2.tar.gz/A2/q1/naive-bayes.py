#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2016 shivam <shivam@Shiganshina>
#
# Distributed under terms of the MIT license.

"""
Naive - Bayes Classifier
"""

import csv
import math
import pdb
import numpy
from collections import defaultdict

GAC = 0
GWA = 0

def ReadnClean():

    r = csv.reader(open("census-income.data"))
    ret = []
    for el in list(r):
        ret.append([x.strip() for x in el])
    return ret



def NaiveBayesTrain(data,positivelabel):

    nattr = len(data[0]) - 1
    dictp = [defaultdict(float) for x in range(nattr)]
    dictn = [defaultdict(float) for x in range(nattr)]
    listp = [0]*nattr
    listn = [0]*nattr

    npsamples = 0
    nnsamples = 0

    for row in data:
        label = row[-1]

        if label==positivelabel:
            cdictlist = dictp
            clist = listp
            npsamples += 1
        else:
            clist = listn
            cdictlist = dictn
            nnsamples += 1
        featurevec = row[:-1]
        idx = -1
        for feature in featurevec:
            idx += 1
            if feature=='?':
                continue
            cdictlist[idx][feature] += 1
            clist[idx] += 1
    
    Tsamples = npsamples + nnsamples
    print(npsamples,nnsamples)
    logPriorP = math.log(npsamples/Tsamples)
    logPriorN = math.log(nnsamples/Tsamples)
    for i in range(nattr):
        for feature in dictp[i]:
            if dictp[i][feature]!=0:
                dictp[i][feature] = math.log(dictp[i][feature]/listp[i])
            else:
                dictp[i][feature] = math.log(0.000001)
        for feature in dictn[i]:
            if dictn[i][feature]!=0:
                dictn[i][feature] = math.log(dictn[i][feature]/listn[i])
            else:
                dictn[i][feature] = mathlog(0.000001)

    return [logPriorP,logPriorN,dictp,dictn]

def NaiveBayes(test,train,positivelabel,negativelabel):

    [logPriorP,logPriorN,dictp,dictn] = NaiveBayesTrain(train,positivelabel)
    AC = 0
    WA = 0
    P = 0
    N = 0

    for row in test:
        answer = row[-1]
        logPsum = logPriorP
        logNsum = logPriorN
        #logPsum = 0
        #logNsum = 0
        featurevec = row[:-1]
        idx = -1
        for feature in featurevec:
            idx += 1
            if feature=='?':
                continue
            #print(dictp[idx][feature],dictn[idx][feature])
            logPsum += dictp[idx][feature]
            logNsum += dictn[idx][feature]
        #print(logPsum,logNsum)
        if logPsum > logNsum:
            myans = positivelabel
        else:
            myans = negativelabel
        if myans==answer:
            AC += 1
        else:
            WA += 1
        if myans==positivelabel:
            P += 1
        else:
            N += 1
    print ("Accuracy",AC/(AC+WA)," over ", AC + WA, " samples.",P,N)
    return AC,WA
            

if __name__=='__main__':
    GAC = 0
    GWA = 0
    o = ReadnClean()
    o = numpy.array(o)
    o = o[:,[2,3,4,41]]
    numpy.random.shuffle(o)
    o = o[:10000]
    for i in range(10):
        numpy.random.shuffle(o)
        AC,WA = NaiveBayes(o[0:2000],o[3000:5000],'50000+.','- 50000.')
        GAC += AC
        GWA += WA
    
    print ("Accuracy",GAC/(GAC+GWA)," over ", GAC + GWA)

