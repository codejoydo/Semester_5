#! /bin/sh
#
# genlabels.sh
# Copyright (C) 2016 shivam <shivam@Shiganshina>
#
# Distributed under terms of the MIT license.
#


cat census-income.names |head -n 68 census-income.names |tail -n 45 >census-income.labels.tmp
awk '{$NF=""; $1=""; printf("%s\n",$0);}' census-income.labels.tmp >census-income.labels
rm census-income.labels.tmp
