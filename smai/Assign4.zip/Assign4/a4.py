from numpy import genfromtxt
my_data = genfromtxt('data1.txt', delimiter=',')